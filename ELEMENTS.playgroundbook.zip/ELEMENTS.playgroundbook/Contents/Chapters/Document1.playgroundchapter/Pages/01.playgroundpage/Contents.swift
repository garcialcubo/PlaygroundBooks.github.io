//#-hidden-code
import UIKit
import PlaygroundSupport
import CoreGraphics
import AVFoundation
import Foundation

//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 */

struct elementsPeriodicTable {
    let name: String
    let symbol: UIImage?
    let valence: String?
    let atomicNumber: Int?
    let backgroundColor: UIColor?
    let objectWithThisElement: UIImage?
}
//#-hidden-code
let cancion = URL.init(fileURLWithPath: Bundle.main.path(forResource: "Minecraft", ofType: "m4a")!)

class PantallaDos: UIViewController {


    let fondoTablaPeriodica = UIView(frame: CGRect(x: 0, y: 0, width: 575, height: 780))
    let imagenTabla = UIImageView(frame: CGRect(x: 50, y: 50, width: 400, height: 200))
    let imagenValencia = UIImageView(frame: CGRect(x: 50, y: 200, width: 400, height: 200))
    let vuelta = UIButton(frame: CGRect(x: 50, y: 600, width: 60, height: 60))

    var arrastrar = UIGestureRecognizer()
    var pinchGesture = UIGestureRecognizer()
    var arrastrarDos = UIGestureRecognizer()
    var pinchGestureDos = UIGestureRecognizer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        imagenTabla.image = #imageLiteral(resourceName: "Tabla-periodica.jpg")
        imagenValencia.image = #imageLiteral(resourceName: "Valencias.jpg")
        
        fondoTablaPeriodica.backgroundColor = .white
        
        pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchedView))
        arrastrar = UIPanGestureRecognizer(target: self, action: #selector(draggedView(_ :)))
        pinchGestureDos = UIPinchGestureRecognizer(target: self, action: #selector(pinchedViewDos))
        arrastrarDos = UIPanGestureRecognizer(target: self, action: #selector(draggedViewDos(_ :)))
        
        fondoTablaPeriodica.isUserInteractionEnabled = true
        imagenTabla.isUserInteractionEnabled = true
        imagenValencia.isUserInteractionEnabled = true
        
        imagenValencia.addGestureRecognizer(pinchGestureDos)
        imagenValencia.addGestureRecognizer(arrastrarDos)
        
        imagenTabla.addGestureRecognizer(pinchGesture)
        imagenTabla.addGestureRecognizer(arrastrar)
        fondoTablaPeriodica.addSubview(imagenValencia)
        fondoTablaPeriodica.addSubview(imagenTabla)

        view.addSubview(fondoTablaPeriodica)
    }
    
    @objc func draggedView(_ sender: UIPanGestureRecognizer) {
        
        self.view.bringSubview(toFront: imagenTabla)
        let translation = sender.translation(in: self.view)
        imagenTabla.center = CGPoint(x: imagenTabla.center.x + translation.x, y: imagenTabla.center.y + translation.y)
        sender.setTranslation(CGPoint.zero, in: self.view)
    }
    
    @objc func draggedViewDos(_ sender: UIPanGestureRecognizer) {
        
        self.view.bringSubview(toFront: imagenValencia)
        let translation = sender.translation(in: self.view)
        imagenValencia.center = CGPoint(x: imagenValencia.center.x + translation.x, y: imagenValencia.center.y + translation.y)
        sender.setTranslation(CGPoint.zero, in: self.view)
    }
    
    @objc func pinchedView(sender: UIPinchGestureRecognizer){
        
        self.view.bringSubview(toFront: imagenTabla)
        sender.view?.transform = (sender.view?.transform)!.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1.0
    }
    
    @objc func pinchedViewDos(sender: UIPinchGestureRecognizer){
        
        self.view.bringSubview(toFront: imagenValencia)
        sender.view?.transform = (sender.view?.transform)!.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1.0
    }
    

}


class ViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UIGestureRecognizerDelegate {
    

    
///DECLARAMOS DATOS
    
    let valences = ["±1", "+1", "+2","+3", "+2,+3,(+6)", "+2,+3,(+4,+6,+7)", "+2,+3", "+1,+2", "+1,+3", "+2,+4", "±3", "+2,±4", "±1,±2,±3,+4,+5", "±3,+5", "-1,-2", "±2,+4,+6", "-2,+4,+6", "-1", "±1,+3,+5,+7"]
    
    let voicesColors = ["Off elements"]
//#-end-hidden-code
/*:#localized(key: "SecondProseBlock")
*/
    var elements = [elementsPeriodicTable(name: "berilio", symbol: #imageLiteral(resourceName: "Berilio.png"), valence: "+2", atomicNumber: 4, backgroundColor: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0), objectWithThisElement: #imageLiteral(resourceName: "Esmeralda.png")), elementsPeriodicTable(name: "magnesio", symbol: #imageLiteral(resourceName: "Magnesio.png"), valence: "+2", atomicNumber: 12, backgroundColor: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0), objectWithThisElement: #imageLiteral(resourceName: "Clorofila.png")), elementsPeriodicTable(name: "calcio", symbol: #imageLiteral(resourceName: "Calcio.png"), valence: "+2", atomicNumber: 20, backgroundColor: #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0), objectWithThisElement: #imageLiteral(resourceName: "Huesos.png")), /*#-editable-code Crea tus elementos*//*#-end-editable-code*/]

//#-hidden-code
  
    var azar = Int()
    var elementsName = [String]()
    var elementsImages = [UIImage]()
    
    let defaults = UserDefaults.standard

    ///DECLARAMOS
    var player = AVAudioPlayer()
    var playerDos = AVAudioPlayer()
    let sound = try! AVAudioPlayer(contentsOf: cancion)
    
    let backgroundInterfaceApp = UIImageView(frame: CGRect(x: 0, y: 0, width: 575, height: 780))

    let fondoDragonBallView = UIView(frame: CGRect(x: 0, y: 0, width: 575, height: 780))
    
    let dragonBallView = UIImageView(frame: CGRect(x: -300, y: 150, width: 200, height: 400))
    
    let explosionDragonBallView = UIImageView(frame: CGRect(x: 600, y: 150, width: 400, height: 200))
    
    let textExplosionDragonBallView = UILabel(frame: CGRect(x: 60, y: 25, width: 240, height: 150))
    
    let scoreLabel = UILabel(frame: CGRect(x: 50, y: 150, width: 70, height: 70))
    
    let textFieldElementName = UITextField(frame: CGRect(x: 100, y: 500, width: 300, height: 50))
    
    
    let elementSquare = UIImageView(frame: CGRect(x: 145, y: 175, width: 225, height: 280))
    
    let pickerView = UIPickerView(frame: CGRect(x: 100, y: 600, width: 300, height: 50))
    
    let botonComienzo = UIButton(frame: CGRect(x: -300, y: 450, width: 50, height: 50))
    
    let botonPicker = UIButton(frame: CGRect(x: -300, y: 550, width: 50, height: 50))
//#-end-hidden-code
 
/// EJEMPLO DE COMO SE CREA UN OBJETO POR CÓDIGO
    
    let botonReset = UIButton(frame: CGRect(x: 50, y: 300, width: 50, height: 50))


/*:#localized(key: "ThirdProseBlock")
*/
    
//#-editable-code Crea tu objeto
//#-end-editable-code

//#-hidden-code
    var valenceResult = String()
    
    var respuestasAcertadas = 0
    
    var preguntasContestadas = 0
    
   
    
    ///VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
///USER DEFAULTS
        
    let respuestasAcertadasActuales = defaults.integer(forKey: "Marcador")

        
        if respuestasAcertadasActuales == nil {
            scoreLabel.text = "\(respuestasAcertadas)"}else{
            respuestasAcertadas = respuestasAcertadasActuales
            scoreLabel.text = "\(respuestasAcertadas)"
            vueltaAlJuegoDeNuevo()
        }
        
///INICIO MÚSICA
    let cancion = URL.init(fileURLWithPath: Bundle.main.path(forResource: "Minecraft", ofType: "m4a")!)
        
        
     
        player = sound
        sound.play()
        
botonReset.setTitle("🔄", for: .normal)
botonReset.addTarget(nil, action: #selector(reset), for: .touchUpInside)

        textExplosionDragonBallView.numberOfLines = 0
        textExplosionDragonBallView.textAlignment = .center
        textExplosionDragonBallView.textColor = .white
        textExplosionDragonBallView.font = UIFont(name: "GeezaPro-Bold", size: 15)
        
    
      
        scoreLabel.font = UIFont(name: "GeezaPro-Bold", size: 50)
        
        backgroundInterfaceApp.image = #imageLiteral(resourceName: "Imagen PNG 5.png")
        backgroundInterfaceApp.isUserInteractionEnabled = true
        
        pickerView.delegate = self
        pickerView.isUserInteractionEnabled = false
        pickerView.layer.cornerRadius = 16
        
        dragonBallView.image = #imageLiteral(resourceName: "dragonBall.png")
        explosionDragonBallView.image = #imageLiteral(resourceName: "explosion-clipart-blue.png")
        fondoDragonBallView.backgroundColor = UIColor.white
        fondoDragonBallView.alpha = 0
        
        botonComienzo.setImage(#imageLiteral(resourceName: "Go.png"), for: .normal)
        botonComienzo.addTarget(nil, action: #selector(entradaBoton), for: .touchUpInside)
        
        botonComienzo.layer.shadowColor = #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)
        botonComienzo.layer.shadowRadius = 4
        botonComienzo.layer.shadowOpacity = 1
        botonComienzo.layer.shadowOffset = CGSize(width: 2, height: 3)
        backgroundInterfaceApp.addSubview(botonComienzo)
        
        botonPicker.setImage(#imageLiteral(resourceName: "745f2cc314a4b27b252b25e2e7117cef-icono-de-tubos-de-qu--mica-by-vexels.png"), for: .normal)
        botonPicker.layer.shadowColor = #colorLiteral(red: 0.34117648005485535, green: 0.6235294342041016, blue: 0.16862745583057404, alpha: 1.0)
        botonPicker.layer.shadowRadius = 4
        botonPicker.layer.shadowOpacity = 1
        botonPicker.layer.shadowOffset = CGSize(width: 2, height: 3)
        botonPicker.addTarget(nil, action: #selector(accionBotonPicker), for: .touchUpInside)
        
        backgroundInterfaceApp.addSubview(botonPicker)
        
        elementSquare.layer.borderWidth = 0.5
        elementSquare.layer.borderColor = #colorLiteral(red: 0.8039215803146362, green: 0.8039215803146362, blue: 0.8039215803146362, alpha: 1.0)
        elementSquare.layer.cornerRadius = 15
        
        var imagenes = [UIImage]()
        
        for elemento in elements {
            imagenes.append(elemento.symbol!)
        }
        
        elementSquare.animationImages = imagenes
        elementSquare.animationDuration = 0.5
        
        textFieldElementName.layer.borderColor = #colorLiteral(red: 0.6000000238418579, green: 0.6000000238418579, blue: 0.6000000238418579, alpha: 1.0)
        textFieldElementName.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        textFieldElementName.layer.cornerRadius = 15
        textFieldElementName.alpha = 0.7
        textFieldElementName.delegate = self
        textFieldElementName.textAlignment = .center
        textFieldElementName.clearsOnBeginEditing = true
        
        
        
        
        
        
        
        UIView.animate(withDuration: 2, animations: {  self.botonComienzo.frame = CGRect(x: 50, y: 450, width: 50, height: 50)
            
        })
        UIView.animate(withDuration: 2, animations: {
            self.botonPicker.frame = CGRect(x: 45, y: 585, width: 50, height: 50)
        })
      
        

        fondoDragonBallView.addSubview(dragonBallView)
        
        explosionDragonBallView.addSubview(textExplosionDragonBallView)
        fondoDragonBallView.addSubview(explosionDragonBallView)
//#-end-hidden-code
/*:#localized(key: "FourProseBlock")
*/
        backgroundInterfaceApp.addSubview(elementSquare)

//#-editable-code elementSquare.addSubview(objectContainsElement)
//#-end-editable-code
//#-hidden-code
        backgroundInterfaceApp.addSubview(textFieldElementName)
        backgroundInterfaceApp.addSubview(scoreLabel)
        backgroundInterfaceApp.addSubview(pickerView)
        backgroundInterfaceApp.addSubview(botonReset)
        
        backgroundInterfaceApp.addSubview(fondoDragonBallView)
        view.addSubview(backgroundInterfaceApp)
        
    }
    @objc func accionBotonPicker(){
        preguntasContestadas += 1
        botonComienzo.isUserInteractionEnabled = true

        pickerView.isUserInteractionEnabled = false
        botonPicker.isUserInteractionEnabled = false
        
        if valenceResult == elements[azar].valence {
            pickerView.backgroundColor = #colorLiteral(red: 0.46666666865348816, green: 0.7647058963775635, blue: 0.2666666805744171, alpha: 1.0)
            respuestasAcertadas += 1
            defaults.set(respuestasAcertadas, forKey: "Marcador")
            scoreLabel.text = "\(respuestasAcertadas)"
            currentBackgroundColor()
        }else{
            preguntasContestadas += 1
        botonComienzo.isUserInteractionEnabled = true


         pickerView.backgroundColor = UIColor.red
            self.show(PantallaDos(), sender: Any?.self)
            
        }
        
        
    }
    
    
    @objc func entradaBoton(){
        
        botonComienzo.isUserInteractionEnabled = false
        botonPicker.isUserInteractionEnabled = true
        textFieldElementName.isUserInteractionEnabled = true
        pickerView.isUserInteractionEnabled = true
        
        textFieldElementName.text = ""
        textFieldElementName.placeholder = "Element"
        textFieldElementName.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
       
        pickerView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        pickerView.isUserInteractionEnabled = true

//#-end-hidden-code
/*:#localized(key: "SixProseBlock")
*/
//#-editable-code objectContainsElement.image = nil
//#-end-editable-code

        
        elementSquare.backgroundColor = nil
        azar = Int(arc4random_uniform(UInt32(elements.count)))
        elementSquare.startAnimating()
        sleep(2)
        elementSquare.stopAnimating()
//#-end-hidden-code

/*:#localized(key: "FiveProseBlock")
*/

        elementSquare.image = elements[azar].symbol
        elementSquare.backgroundColor = elements[azar].backgroundColor

//#-editable-code eobjectContainsElement.image = element[azar].objectWithThisElement
//#-end-editable-code
//#-hidden-code

    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
   
        UIView.animate(withDuration: 0.3, animations: {
    self.backgroundInterfaceApp.frame = CGRect(x: 0, y: -300, width: 520, height: 780)
    })
    
    return true
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return valences.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    
    return valences[row]
    
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("hola")
        valenceResult = valences[row]
        print(valenceResult)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    textField.resignFirstResponder()
   
    preguntasContestadas += 1
    /*
if preguntasContestadas == 2 {
            botonComienzo.isUserInteractionEnabled = true
        }
*/
    UIView.animate(withDuration: 0.3, animations: {
    self.backgroundInterfaceApp.frame = CGRect(x: 0, y: 0, width: 520, height: 780)
    })
    let textFieldCapital = textFieldElementName.text!.lowercased()
    if textFieldCapital == elements[azar].name || textFieldCapital == elements[azar].name + " " {
    textFieldElementName.backgroundColor = #colorLiteral(red: 0.46666666865348816, green: 0.7647058963775635, blue: 0.2666666805744171, alpha: 1.0)
        respuestasAcertadas += 1
        defaults.set(respuestasAcertadas, forKey: "Marcador")
        scoreLabel.text = "\(respuestasAcertadas)"
        currentBackgroundColor()
textFieldElementName.isUserInteractionEnabled = false
botonComienzo.isUserInteractionEnabled = true
    }else{
        
    textFieldElementName.backgroundColor = #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)
textFieldElementName.isUserInteractionEnabled = false
botonComienzo.isUserInteractionEnabled = true
sleep(1 )
        self.show(PantallaDos(), sender: Any?.self)
        print("Eureka")
        }
    return true
    }
    
    
    func currentBackgroundColor(){
        
        switch respuestasAcertadas {
        case 10:
            textExplosionDragonBallView.text = "Primer Nivel alcanzado. Has conseguido el fondo Blanco Níveo"
            saleDragonBall()
            backgroundInterfaceApp.backgroundColor = UIColor.white
            sleep(2)
            vueltaDragonBall()
            
        case 20:
            textExplosionDragonBallView.text = "Segundo Nivel alcanzado. Has conseguido el fondo Amarillo Inferno."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.yellow
            vueltaDragonBall()
            
        case 30:
            textExplosionDragonBallView.text = "Tercer Nivel alcanzado. Has conseguido el fondo Naranja lava de volcán."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.orange
            vueltaDragonBall()
        
        case 40:
            textExplosionDragonBallView.text = "Cuarto Nivel alcanzado. Has conseguido el fondo Verde esmeralda."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.green
            vueltaDragonBall()
        
        case 50:
            textExplosionDragonBallView.text = "Quinto Nivel alcanzado. Has conseguido el fondo Azul fondo marino."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.blue
            vueltaDragonBall()
        
        case 60:
            textExplosionDragonBallView.text = "Sexto Nivel alcanzado. Has conseguido el fondo Marrón tierra."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.brown
            vueltaDragonBall()
            
            
        case 70:
            textExplosionDragonBallView.text = "¡Enhorabuena! Has llegado al nivel máximo. Has conseguido el mítico fondo negro profundo."
            saleDragonBall()
            sleep(3)
            backgroundInterfaceApp.backgroundColor = UIColor.black
            vueltaDragonBall()
            
        default: break
        }
        
        
    }
    
    func vueltaAlJuegoDeNuevo(){
        
        switch respuestasAcertadas {
        case 10...19:
            
            backgroundInterfaceApp.backgroundColor = UIColor.white
           
            
        case 20...29:
            
            backgroundInterfaceApp.backgroundColor = UIColor.yellow
           
        case 30...39:
            backgroundInterfaceApp.backgroundColor = UIColor.orange
            
        case 40...49:
            backgroundInterfaceApp.backgroundColor = UIColor.green
            
        case 50...59:
            backgroundInterfaceApp.backgroundColor = UIColor.blue
            
        case 60...69:
            backgroundInterfaceApp.backgroundColor = UIColor.brown
            
        case 70:
            backgroundInterfaceApp.backgroundColor = UIColor.black
            
        default: break
        }
        
        
    }

   
    func saleDragonBall(){
        UIView.animate(withDuration: 0.6, animations: {
            self.fondoDragonBallView.alpha = 1
        })
        
        UIView.animate(withDuration: 0.6, animations: {
            self.dragonBallView.frame = CGRect(x: 50, y: 150, width: 200, height: 300)
        })
        
        UIView.animate(withDuration: 0.6, animations: {
            self.explosionDragonBallView.frame = CGRect(x: 150, y: 250, width: 400, height: 200)
        })
    }
    
    func vueltaDragonBall(){
        UIView.animate(withDuration: 0.6, animations: {
            self.fondoDragonBallView.alpha = 0
        })
        
        UIView.animate(withDuration: 0.6, animations: {
            self.dragonBallView.frame = CGRect(x: -300, y: 150, width: 200, height: 300)
        })
        UIView.animate(withDuration: 0.6, animations: {
            self.explosionDragonBallView.frame = CGRect(x: 600, y: 250, width: 400, height: 200)
        })
    }
@objc func reset(){

respuestasAcertadas = 0
defaults.set(respuestasAcertadas, forKey: "Marcador")
        scoreLabel.text = "\(respuestasAcertadas)"
    vueltaAlJuegoDeNuevo()

}
}


PlaygroundPage.current.liveView = UINavigationController(rootViewController: ViewController())

